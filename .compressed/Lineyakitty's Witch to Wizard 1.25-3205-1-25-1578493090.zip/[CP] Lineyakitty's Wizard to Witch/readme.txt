For the config file, simply change the No to a Yes to switch the references to the Witch's ex-wife to her ex-husband. If you have the pretty witch mod then you can use it or place it into the assets folder named Cursors_Witch and set the config to Yes for the pretty witch option. You cannot have both config options set to Yes.

If you already use something like LavenderLight's DIYCP for portraits and characters, then simply delete the relevant sections at the top of the content file for replacing the images and add the image file's to the other mod's asset folder as needed.

Feel free to change her name by simply finding and replacing Rasmodia and M. Rasmodia with whatever name you like!


Send me any questions, concerns, or suggestions on the mod page or to my Discord.

Discord Link: https://discord.gg/d7DqK46