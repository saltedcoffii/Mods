#! README
Hello and thank you for downloading! 

How to configure this mod:
There are three styles of a shorter hair Sam (seen in the file styles.png)
1. The original Sam short hair by jessicashooch.
2. An altered version of the Great and Cool Haircut by thalabee, where Sam wears his vanilla clothing.
3. The original Great and Cool Haircut by thalabee.

To change between styles, open the config.json file in your text editor and change
"SamStyle": "2"
to any of the following:
"SamStyle": "1"
"SamStyle": "2"
"SamStyle": "3"


And that's pretty much it! Like the mod? Don't forget to endorse! Want to see compatibility with another mod (like Diversity or DCBurger)? Don't hesitate to ask in the comments! And check out my other mods!

Emmett - Male Emily Mod for Content Patcher: https://www.nexusmods.com/stardewvalley/mods/4947
Dark Red Hair Leah for Content Patcher: https://www.nexusmods.com/stardewvalley/mods/4983
Hispanic Alex for Content Patcher: https://www.nexusmods.com/stardewvalley/mods/4988
Hispanic George for Content Patcher: https://www.nexusmods.com/stardewvalley/mods/4987
Female Mariner: https://www.nexusmods.com/stardewvalley/mods/4985

Happy Modding!
~kingliamb
